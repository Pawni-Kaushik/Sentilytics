# ====================================================================
# HOW TO APPLY (in YOUR utils/predictor.py):
#
# 1. Find the line:   LEXICON_VOTE_WEIGHT = 12
# 2. Delete everything from that line down to the END of the function
#    predict_long_text(...)  (stop just before
#    def get_top_contributing_words).
#    This removes: LEXICON_VOTE_WEIGHT, VADER_VOTE_WEIGHT, _vader_vote(),
#    and the old predict_long_text().
# 3. Paste everything BELOW this comment block in their place.
#
# Keep your existing NEGATIVE_SIGNAL_PHRASES / POSITIVE_SIGNAL_PHRASES
# lists and your _vader = SentimentIntensityAnalyzer() line untouched.
# ====================================================================

# ---------------------------------------------------------------------
# How much each signal source is trusted (must sum to 1.0 before the
# lexicon boost is folded in).
#
# WHY VADER, SCORED ON THE WHOLE TEXT, LEADS:
# Testing against real, formally-worded text (news articles, not the
# short synthetic Reddit-style snippets the model was trained on) showed
# two things:
#   1. The raw LSTM confidently mis-scores plainly neutral factual
#      sentences on its own -- e.g. "This car uses a diesel engine" ->
#      64% negative, "The company said it will appeal" -> 94.5%
#      positive. It has real signal on short, casual text, but isn't
#      reliable enough on real-world prose to lead.
#   2. Scoring VADER sentence-by-sentence and averaging loses the
#      whole-document context VADER's own algorithm uses, so a clearly
#      negative multi-paragraph article can average out to a coin-flip.
#      Running VADER on the FULL text once recovers that.
# ---------------------------------------------------------------------
MODEL_WEIGHT = 0.15
VADER_WEIGHT = 0.85
NEUTRAL_ZONE = 0.35            # |compound| at/above this is treated as fully decided, not neutral
LEXICON_OVERRIDE_WEIGHT = 0.5  # how much one matched phrase adds, in the same 0-1 probability space


def _vader_distribution(text: str, zone: float = NEUTRAL_ZONE):
    """
    Converts VADER's compound score (-1..1) into a 3-way probability
    distribution (positive/neutral/negative) instead of a hard
    threshold pick. Below `zone`, the unresolved magnitude is neutral,
    so weak/ambiguous signals land near neutral. At or above `zone`,
    VADER is confident enough that the full weight goes to that side.

    Returns (dist_dict, compound_score).
    """
    compound = _vader.polarity_scores(text)["compound"]
    if compound == 0:
        return {"positive": 0.0, "neutral": 1.0, "negative": 0.0}, compound

    magnitude = min(abs(compound) / zone, 1.0)
    neutral_share = 1.0 - magnitude
    if compound > 0:
        dist = {"positive": magnitude, "neutral": neutral_share, "negative": 0.0}
    else:
        dist = {"positive": 0.0, "neutral": neutral_share, "negative": magnitude}
    return dist, compound


def predict_long_text(text: str, model, tokenizer, encoder, max_chunk_words: int = 30):
    """
    Sentiment for long-form text (posts/comments/articles spanning
    several sentences).

    The final verdict blends:
      - VADER, scored on the WHOLE text at once (_vader_distribution):
        the PRIMARY signal for real, formally-worded text.
      - The trained LSTM, scored per sentence-sized chunk and
        length-weight-averaged: a MINORITY signal, since it's only
        reliable on short, casual, Reddit-style text. Chunking still
        matters here because max_len=40 would otherwise silently
        truncate a long text.
      - NEGATIVE_SIGNAL_PHRASES / POSITIVE_SIGNAL_PHRASES: unambiguous
        phrases that boost the blend when matched anywhere in the text.

    Returns the same shape as predict_sentiment(), plus chunk_results
    (the model's per-chunk predictions, kept for the "why" breakdown).
    """
    chunks = _split_into_chunks(text, max_chunk_words)
    chunk_results = [(chunk, predict_sentiment(chunk, model, tokenizer, encoder)) for chunk in chunks]

    if not chunk_results:
        fallback = predict_sentiment(text, model, tokenizer, encoder)
        fallback["chunk_results"] = []
        return fallback

    labels = list(encoder.classes_)

    model_probs = {label: 0.0 for label in labels}
    total_weight = 0.0
    for chunk, result in chunk_results:
        weight = max(len(chunk.split()), 1)
        total_weight += weight
        for _, row in result["probabilities"].iterrows():
            model_probs[row["Sentiment"]] += (row["Probability"] / 100.0) * weight
    for label in labels:
        model_probs[label] /= total_weight

    vader_dist, _ = _vader_distribution(text)

    blended = {
        label: MODEL_WEIGHT * model_probs.get(label, 0.0) + VADER_WEIGHT * vader_dist.get(label, 0.0)
        for label in labels
    }

    text_lower = text.lower()
    neg_hits = sum(1 for phrase in NEGATIVE_SIGNAL_PHRASES if phrase in text_lower)
    pos_hits = sum(1 for phrase in POSITIVE_SIGNAL_PHRASES if phrase in text_lower)
    if neg_hits and "negative" in blended:
        blended["negative"] += neg_hits * LEXICON_OVERRIDE_WEIGHT
    if pos_hits and "positive" in blended:
        blended["positive"] += pos_hits * LEXICON_OVERRIDE_WEIGHT

    blend_total = sum(blended.values()) or 1.0
    weighted_probs = {label: (blended[label] / blend_total) * 100.0 for label in labels}

    probabilities = pd.DataFrame({
        "Sentiment": labels,
        "Probability": [weighted_probs[l] for l in labels],
    })

    pred_label = max(weighted_probs, key=weighted_probs.get)
    confidence = weighted_probs[pred_label]

    return {
        "prediction": pred_label,
        "confidence": confidence,
        "masked_text": " | ".join(r["masked_text"] for _, r in chunk_results),
        "cleaned_text": " | ".join(r["cleaned_text"] for _, r in chunk_results),
        "probabilities": probabilities,
        "is_oov": False,
        "chunk_results": [
            {"chunk": c, "prediction": r["prediction"], "confidence": round(r["confidence"], 1)}
            for c, r in chunk_results
        ],
    }